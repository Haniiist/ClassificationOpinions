package main;

import java.io.IOException;

import preparation.Loader;

public class Test {

	
	public static void main(String[] args) throws IOException
	{
		Loader l = new Loader();
		l.load();
		l.makeArff();
	}
}
