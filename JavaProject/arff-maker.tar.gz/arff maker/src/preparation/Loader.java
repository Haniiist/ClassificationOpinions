package preparation;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import extra.IOTool;

public class Loader {

	private ArrayList<String> opinions;
	private ArrayList<Integer> opinionsClass;
	private ArrayList<String> stopWords;
	public void load() throws IOException
	{
		load_opinions();
		load_opinionValues();
		stopWords = IOTool.readStopWords("StopWords");
		
		//for(int i=0; i<opinions.size(); i++)
		//opinions.add(i, (HelpTool.preTreat(opinions.get(i), stopWords)));
	}
	
	public void load_opinions()
	{
		opinions = IOTool.readFile("dataset.csv");
		/*for(String s: opinions)
			System.out.println(s);*/
	}
	
	public void load_opinionValues()
	{
		System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------");
		opinionsClass = new ArrayList<Integer>();
		for(String s: IOTool.readFile("labels.csv"))
			opinionsClass.add(Integer.parseInt(s));
		
	}
	
	public void initArff() throws IOException
	{
		BufferedWriter bw = new BufferedWriter(new FileWriter("cote.arff"));
		
		bw.write("@RELATION cote");
		bw.newLine();
		bw.newLine();
		bw.write("@ATTRIBUTE text STRING");
		bw.newLine();
		bw.write("@ATTRIBUTE label {-1,1}");
		bw.newLine();
		bw.newLine();
		bw.write("@DATA");
		bw.newLine();
		bw.close();
	}
	
	public void makeArff() throws IOException
	{
		initArff();
		BufferedWriter bw = new BufferedWriter(new FileWriter("cote.arff", true));
		for(int i=0; i<opinions.size(); i++)
			{
			bw.write(opinions.get(i)+","+opinionsClass.get(i));
			bw.newLine();
			}
		bw.close();
	}
}
