package preparation;

import java.util.ArrayList;

public abstract class HelpTool {

	public static String preTreat(String text, ArrayList<String> stopWords)
	{
		String treatedText;
		treatedText = text.replaceAll(",", " ").replaceAll("\\.", " ").replaceAll("[^\\x00-\\x7F]", "").toLowerCase();
		String[] words = treatedText.split(" ");
		if(stopWords.contains(words[0].toLowerCase()))
			treatedText = treatedText.substring(words[0].length()+1, treatedText.length());
		
		for(String stopWord: stopWords)
		{
			treatedText = treatedText.replaceAll(" "+ stopWord+" ", " ");
		}
		
		return treatedText;
	}
}
