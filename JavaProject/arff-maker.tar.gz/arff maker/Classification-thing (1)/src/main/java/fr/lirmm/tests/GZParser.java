package fr.lirmm.tests;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.io.LineIterator;
import org.json.JSONException;
import org.json.JSONObject;

import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.TwitterObjectFactory;

public class GZParser{
	private LinkedBlockingQueue<File> queue;
	private File[] allgzFiles;
	private File currentfile;
	private LineIterator lineIterator;
	private ArrayList<String> tweets = new ArrayList<String>();
	private ArrayList<String> retweets = new ArrayList<String>();
	int nbTweets = 0;
	public void open(File file) throws IOException {
		File gzDirectory = file;
		queue = new LinkedBlockingQueue<File>();

		allgzFiles = gzDirectory.listFiles();
		// Sort files by ascending order of their names
		Arrays.sort(allgzFiles);
		
		for (File gzfile : allgzFiles) {
			// if (gzfile.getName().endsWith("gz"))
			System.out.println("Order : " + gzfile.getName());
			queue.offer(gzfile);
		}
		System.out.println(queue.size() + " files to process...");
		this.currentfile = queue.poll();

		try {
			if (this.currentfile.getName().endsWith("gz") || this.currentfile.getName().startsWith("statuses.log.")) {
				GzippedFileReader fzreader = new GzippedFileReader(this.currentfile);
				this.lineIterator = fzreader.getLineIterator();
				String str = "First open! processing file : " + this.currentfile.getName();
				System.out.println(str);
				System.out.println("----");
				System.out.println(str);

				if ((this.lineIterator != null)) {
							// System.out.println("line it ININ is good " );

					while (this.lineIterator.hasNext() && nbTweets < 200) {

						String line = this.lineIterator.nextLine().toString();
						if (line != null) {

							if (!(line.isEmpty()) && !line.startsWith("{\"delete\":{")) {
								try {

									// System.out.println("line : " + line);
									//---------MOD
									
										
									 try {
										JSONObject jsonObj = new JSONObject(line);
										String tweet = jsonObj.getString("text");
										if(tweet.substring(0, 2).equals("RT"))
											retweets.add(tweet);
										else
											{
											tweets.add(tweet);
											nbTweets++;
											System.out.println(tweet);
											System.out.println("-----------------------------------------");
											}
										
										
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									
									//----
									Status status = TwitterObjectFactory.createStatus(line);
									if (status != null) {
										//nbline++;
									}
								} catch (TwitterException e) {
									// System.out.println("Exception Spout statuseslog :
									// " + this.currentfile.getName() + " : "
									// + " line : " + line + " - " + e.getMessage());
									// TODO : deleted statuses should be removed from
									// the databases !
								}
							}
						}
					}
				}

						
			} else
				System.out.println("First open! ignoring file : " + this.currentfile.getName());

			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public void open(File file, int nTweets) {
		File gzDirectory = file;
		queue = new LinkedBlockingQueue<File>();

		allgzFiles = gzDirectory.listFiles();
		// Sort files by ascending order of their names
		Arrays.sort(allgzFiles);
		
		for (File gzfile : allgzFiles) {
			// if (gzfile.getName().endsWith("gz"))
			System.out.println("Order : " + gzfile.getName());
			queue.offer(gzfile);
		}
		System.out.println(queue.size() + " files to process...");
		this.currentfile = queue.poll();

		try {
			if (this.currentfile.getName().endsWith("gz") || this.currentfile.getName().startsWith("statuses.log.")) {
				GzippedFileReader fzreader = new GzippedFileReader(this.currentfile);
				this.lineIterator = fzreader.getLineIterator();
				String str = "First open! processing file : " + this.currentfile.getName();
				System.out.println(str);
				System.out.println("----");
				System.out.println(str);

				if ((this.lineIterator != null)) {
							// System.out.println("line it ININ is good " );

					while (this.lineIterator.hasNext() && nbTweets < nTweets) {

						String line = this.lineIterator.nextLine().toString();
						if (line != null) {

							if (!(line.isEmpty()) && !line.startsWith("{\"delete\":{")) {
								try {

									// System.out.println("line : " + line);
									//---------MOD
									
										
									 try {
										JSONObject jsonObj = new JSONObject(line);
										String tweet = jsonObj.getString("text");
										if(tweet.substring(0, 2).equals("RT"))
											retweets.add(tweet);
										else
											{
											tweets.add(tweet);
											nbTweets++;
											System.out.println(tweet);
											System.out.println("-----------------------------------------");
											}
										
										
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									
									//----
									Status status = TwitterObjectFactory.createStatus(line);
									if (status != null) {
										//nbline++;
									}
								} catch (TwitterException e) {
									// System.out.println("Exception Spout statuseslog :
									// " + this.currentfile.getName() + " : "
									// + " line : " + line + " - " + e.getMessage());
									// TODO : deleted statuses should be removed from
									// the databases !
								}
							}
						}
					}
				}

						
			} else
				System.out.println("First open! ignoring file : " + this.currentfile.getName());

			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	

	
	public ArrayList<String> getTweets()
	{
		return tweets;
	}
	

		
	

	
	
}




	
