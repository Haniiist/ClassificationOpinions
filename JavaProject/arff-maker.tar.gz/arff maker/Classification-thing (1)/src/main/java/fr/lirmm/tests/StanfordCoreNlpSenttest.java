package fr.lirmm.tests;


import java.util.ArrayList;
import java.util.Properties;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations.SentimentAnnotatedTree;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.util.CoreMap;

public class StanfordCoreNlpSenttest {

	public static int[] getSentiments(ArrayList<String> sentences, boolean show)
	{
		
		int sent; //Sentiment value at each iteration, for each tweet
		StanfordCoreNlpSenttest sentimentAnalyzer = new StanfordCoreNlpSenttest();
		//int  sent1 = 0, sent2 = 0, sent3 = 0, sent4 = 0, sent5 = 0;
		int sents[] = new int[5]; //Array containing sentiments for each sentiment type, will be used for output
		
		for(int i=0; i<sents.length; i++)
		{
			sents[i] = 0;
		}
		
		for(String tweet: sentences)
		{
			sent = sentimentAnalyzer.findSentiment(tweet);
		/*	switch (sent) {
            case 0:  sent1++;
                     break;
            case 1:  sent2++;
                     break;
            case 2:  sent3++;
                     break;
            case 3:  sent4++;
                     break;
            case 4:  sent5++;
            break;
            default: System.out.println("----------------------------------ERROR-------------------------ERROR");
                     break;
			}*/
			
			sents[sent]++;
                   
		}
		//  System.out.println("0: " + sent1 + " || 1: " + sent2 + " || 2: " + sent3 + " || 3: " + sent4 + " || 4: " + sent5);
		
		if(show == true)
		for(int i = 0; i < sents.length; i++)
			{
				System.out.println(sentimentAnalyzer.toCss(i) + ": " + sents[i]);
			}
		return sents;
		}
	
	public static ArrayList<String> getPositiveTweets(ArrayList<String> sentences, boolean show)
	{
		int sent; 
		boolean first = true;
		StanfordCoreNlpSenttest sentimentAnalyzer = new StanfordCoreNlpSenttest();
		ArrayList<String> positiveTweets = new ArrayList<String>();
		
		
		
		for(String tweet: sentences)
		{
			sent = sentimentAnalyzer.findSentiment(tweet);
			
			if(sent>1)
				{
				positiveTweets.add(tweet);
				StreamTool.saveIntoFile(tweet, "positive.txt", !first);
				first = false;
				}
                   
			
		}
		
		if(show == true)
		for(int i = 0; i < positiveTweets.size(); i++)
			{
				System.out.println(positiveTweets.get(i));
			}
		return positiveTweets;
	}
	
    public int findSentiment(String line) {

        Properties props = new Properties();
        props.setProperty("annotators", "tokenize, ssplit, parse, sentiment");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
        int mainSentiment = 0;
        if (line != null && line.length() > 0) {
            int longest = 0;
            Annotation annotation = pipeline.process(line);
            for (CoreMap sentence : annotation.get(CoreAnnotations.SentencesAnnotation.class)) {
                Tree tree = sentence.get(SentimentAnnotatedTree.class);
                int sentiment = RNNCoreAnnotations.getPredictedClass(tree);
                String partText = sentence.toString();
                if (partText.length() > longest) {
                    mainSentiment = sentiment;
                    longest = partText.length();
                }

            }
        }
        
      
        return (mainSentiment);

    }

    public static int getTotal(int[] sentimentValues)
    {
    	int s = 0;
    	for(int i: sentimentValues)
    		s = s+i;
    	return s;
    }
    
	public static void howNegative(int[] sentimentValues)
	{
		int total = getTotal(sentimentValues);
		String level;
		int positivity = -sentimentValues[0]*3 + -sentimentValues[1] + sentimentValues[3] + sentimentValues[4]*3;
		if(positivity < 0)
		{
			level = "Negativity";
			if(positivity < -total/2)
				System.out.println("These tweets are very negative");
			else
				System.out.println("These tweets are negative");
		}
		else
		{
			level = "Positivity";
			if(positivity > 0)
				if(positivity > total/2)
					System.out.println("These tweets are very positive");
				else
					System.out.println("These tweets are positive");
			else
				System.out.println("somehow, these tweets are perfectly neutral...");
		}
		
		
		System.out.print(": " + positivity + "/" + total + "-------" + level + " level: " +(float)100*positivity/total + "%");
		
	}
    
    public String toCss(int sentiment) {
        switch (sentiment) {
        case 0:
            return "Very negative";
        case 1:
            return "Negative";
        case 2:
            return "Neutral";
        case 3:
            return "Positive";
        case 4:
            return "Very positive";
        default:
            return "";
        }
    }

	
    
    
    
   /* public static void main(String[] args) {
   
        StanfordCoreNlpSenttest sentimentAnalyzer = new StanfordCoreNlpSenttest();
        int tweetWithSentiment = sentimentAnalyzer
                .findSentiment("He's gonna be the best president the world has ever seen");
        System.out.println(sentimentAnalyzer.toCss(tweetWithSentiment));
        
    }*/
}