package fr.lirmm.tests;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public abstract class StreamTool {

	public static void saveArrayIntoFile(int[] array, String fileName)
	{
	
		int total = StanfordCoreNlpSenttest.getTotal(array);
		    try {
		    		BufferedWriter outputWriter =new BufferedWriter(new FileWriter(fileName));
		    		for(int i: array)
		    		{
		    		outputWriter.write(Integer.toString(i));
		    		outputWriter.newLine();
		    		}
		    		outputWriter.write(Integer.toString(total));
				    outputWriter.close();  
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		 
	}
	
	public static int[] openArrayFromFile(String fileName, int arrayLength)
	{
	int[] array = new int[arrayLength];
	try {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		for(int i=0; i < arrayLength; i++)
			if(i < arrayLength)
			array[i] = Integer.parseInt(br.readLine());
		br.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return array;
	}
	
	
	public static void saveIntoFile(String text, String fileName, Boolean keep)
	{
		FileWriter fw;
		final String LINE_SEPARATOR = "\n";
		try {
			fw = new FileWriter(fileName, keep);
			fw.append(text);
			fw.append(LINE_SEPARATOR);
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
		
	}
	
	public static ArrayList<String> readStopWords(String filePath) throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		ArrayList<String> stopWords = new ArrayList<String>();
		
		String stopWord = br.readLine().trim(); 
		while(stopWord != null && !stopWord.equals(""))
		{
			stopWords.add(stopWord);
			stopWord = br.readLine();
			if(stopWord != null)
				stopWord = stopWord.trim();
		}
			br.close();
			return stopWords;
	}
}
