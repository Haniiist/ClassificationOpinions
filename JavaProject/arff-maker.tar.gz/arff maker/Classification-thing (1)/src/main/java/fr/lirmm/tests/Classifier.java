package fr.lirmm.tests;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

public class Classifier {

	private HashMap<String, ArrayList<String>> classTerms;
	
	public void initializeClasses(HashMap<String, ArrayList<String>> classTerms)
	{
		this.classTerms = classTerms;
	}
	
	public void initializeClasses(String classesFilePath) throws IOException
	{
		HashMap<String, ArrayList<String>> classTerms = new HashMap<String, ArrayList<String>>();
		BufferedReader br = new BufferedReader(new FileReader(classesFilePath));
		String line = br.readLine().trim(); 
		while(line != null && !line.equals(""))
		{
			System.out.println(line);
			String[] parts = line.split(":");
			String sentimentClass = parts[0];
			String classWords = parts[1];
			String[] words = classWords.split(",");
			classTerms.put(sentimentClass, new ArrayList<String>(Arrays.asList(words)));
			line = br.readLine().trim();
		}
			br.close();
			initializeClasses(classTerms);
	}
	
	public ArrayList<String> getClasses()
	{
		return new ArrayList<String>(classTerms.keySet());
	}
	
	public ArrayList<String> getWordsFor(String className)
	{
		return classTerms.get(className);
	}
	
	public String classify(String text)
	{
		ArrayList<String> textWords = new ArrayList<String>(Arrays.asList(text.split(" ")));
		ArrayList<String> classes = getClasses();
		HashMap<String, Integer> nOccurences = new HashMap<String, Integer>();
		//String[][] classPower = new String[classes.size()][1];
		
		for(String className: classes)
		{
			nOccurences.put(className, 0);
		}
		
		for(String word: textWords)
		{
			for(String className: classes)
				nOccurences.put(className, nOccurences.get(className) + Collections.frequency(getWordsFor(className), word.trim()));
		}
		
		System.out.println(nOccurences);
		String dominatingSentiment = "NULL";
		String secondDominatingSentiment = "NULL";
		int dominatingValue = 0;
		int secondHighestValue = 0;
		for(String className: classes)
		{
			int classValue = nOccurences.get(className);
			if(classValue > dominatingValue)
				{
				secondDominatingSentiment = dominatingSentiment;
				dominatingSentiment = className;
				secondHighestValue = dominatingValue;
				dominatingValue = classValue;
				}
		}
		if(secondDominatingSentiment.equals("NULL"))
			secondDominatingSentiment = "the other sentiment classes";
		if(!dominatingSentiment.equals("NULL"))
			System.out.println(dominatingSentiment + " is dominating with a score of: " + dominatingValue +" --which is " + (dominatingValue-secondHighestValue) + " over " + secondDominatingSentiment);
		else
			System.out.println("The sentence bears no sentiment");
		return dominatingSentiment;
	}
	
	public String toString()
	{
		return classTerms.toString();
	}
	
	
}
