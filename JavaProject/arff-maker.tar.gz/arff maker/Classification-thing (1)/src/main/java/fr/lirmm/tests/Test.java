package fr.lirmm.tests;

import java.io.IOException;
import java.util.ArrayList;

public class Test {

	public static void main(String[] args) throws IOException
	{
		
		//GZParser p = new GZParser();
		//p.open(new File("Tweets"), 1000);
		
		
		//ArrayList<String> sents= StanfordCoreNlpSenttest.getPositiveTweets(p.getTweets(), true);
		Classifier c = new Classifier();
		c.initializeClasses("Sentiment classes.txt");
		ArrayList<String> classes = new ArrayList<String>(c.getClasses());
		System.out.println("\n");
		System.out.println(classes);
		System.out.println("\n");
		for(String className: classes)
		{
			System.out.println(className + ": " + c.getWordsFor(className));
		}
		
		System.out.println(c.getWordsFor("Happiness").contains("blissful"));
		
		ArrayList<String> stopWords = StreamTool.readStopWords("Stop words.txt");
		String text = "I'm really beat and depressed, I'm not sure what I'm gonna do with my life now, I'm worried about what's going to happen and I feel really helpless and devastated";
		String treatedText = HelpTool.preTreat(text, stopWords);
		System.out.println("\n\n"+treatedText);
		System.out.println();
		c.classify(treatedText);
		/*StanfordCoreNlpSenttest.howNegative(sents);
		StreamTool.saveArrayIntoFile(sents, "sents20");	
		
		
		
		
		System.out.println("-------------------");
		sents = StreamTool.openArrayFromFile("sents2", 5);
		StanfordCoreNlpSenttest.howNegative(sents);*/
		

	}
}
